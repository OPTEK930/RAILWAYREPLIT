import React from 'react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity } from '@shared/schema';
import { formatDate } from '@/lib/googleSheetsApi';

interface ActivityTableProps {
  activities: Activity[];
  isLoading?: boolean;
  totalCount?: number;
  currentPage?: number;
  onPageChange?: (page: number) => void;
}

const getStatusColor = (status: string): string => {
  const statusMap: Record<string, string> = {
    'Completed': 'bg-green-100 text-green-800',
    'Paid': 'bg-green-100 text-green-800',
    'Processing': 'bg-yellow-100 text-yellow-800',
    'Ordered': 'bg-yellow-100 text-yellow-800',
    'Pending': 'bg-yellow-100 text-yellow-800',
    'Overdue': 'bg-red-100 text-red-800',
    'Adjusted': 'bg-gray-100 text-gray-800',
    'In Progress': 'bg-blue-100 text-blue-800',
    'Quality Check': 'bg-blue-100 text-blue-800',
    'Rejected': 'bg-red-100 text-red-800',
    'Received': 'bg-green-100 text-green-800',
  };
  
  return statusMap[status] || 'bg-gray-100 text-gray-800';
};

const getTypeColor = (type: string): string => {
  const typeMap: Record<string, string> = {
    'Production': 'bg-blue-100 text-blue-800',
    'Sale': 'bg-green-100 text-green-800',
    'Purchase': 'bg-yellow-100 text-yellow-800',
    'Inventory': 'bg-gray-100 text-gray-800',
  };
  
  return typeMap[type] || 'bg-gray-100 text-gray-800';
};

const ActivityTable: React.FC<ActivityTableProps> = ({ 
  activities, 
  isLoading = false,
  totalCount = 0,
  currentPage = 1,
  onPageChange = () => {} 
}) => {
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-72 animate-pulse bg-gray-200 rounded"></div>
        </CardContent>
      </Card>
    );
  }
  
  const itemsPerPage = 5;
  const totalPages = Math.ceil(totalCount / itemsPerPage);
  
  return (
    <Card>
      <CardHeader className="px-4 py-3 border-b border-gray-200">
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="bg-gray-50">
            <TableRow>
              <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Date</TableHead>
              <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Type</TableHead>
              <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Description</TableHead>
              <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</TableHead>
              <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Value</TableHead>
              <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {activities.map((activity) => (
              <TableRow key={activity.id} className="hover:bg-blue-50">
                <TableCell className="text-sm text-gray-900">
                  {formatDate(activity.date as string)}
                </TableCell>
                <TableCell className="text-sm">
                  <Badge className={getTypeColor(activity.type)} variant="outline">
                    {activity.type}
                  </Badge>
                </TableCell>
                <TableCell className="text-sm text-gray-900">{activity.description}</TableCell>
                <TableCell className="text-sm text-gray-900">{activity.quantity}</TableCell>
                <TableCell className="text-sm text-gray-900">{activity.value}</TableCell>
                <TableCell className="text-sm">
                  <Badge className={getStatusColor(activity.status)} variant="outline">
                    {activity.status}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      <CardFooter className="px-4 py-3 border-t border-gray-200 flex justify-between items-center">
        <span className="text-sm text-gray-500">Showing {activities.length} of {totalCount} entries</span>
        <Pagination>
          <PaginationContent>
            <PaginationItem>
              <PaginationPrevious 
                onClick={() => onPageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className={currentPage === 1 ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
              />
            </PaginationItem>
            {Array.from({ length: Math.min(3, totalPages) }, (_, i) => (
              <PaginationItem key={i}>
                <button
                  className={`px-3 py-1 text-sm rounded ${
                    currentPage === i + 1 ? 'bg-blue-500 text-white' : 'hover:bg-gray-100'
                  }`}
                  onClick={() => onPageChange(i + 1)}
                >
                  {i + 1}
                </button>
              </PaginationItem>
            ))}
            <PaginationItem>
              <PaginationNext 
                onClick={() => onPageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className={currentPage === totalPages ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
              />
            </PaginationItem>
          </PaginationContent>
        </Pagination>
      </CardFooter>
    </Card>
  );
};

export default ActivityTable;
