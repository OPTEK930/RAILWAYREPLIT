import React from 'react';
import { Eye } from 'lucide-react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatDate } from '@/lib/googleSheetsApi';

interface LowStockItem {
  id: number;
  name: string;
  currentStock: number;
  minStockLevel: number;
  unit: string;
  lastUpdated?: Date | string;
}

interface LowStockAlertProps {
  items: LowStockItem[];
  isLoading?: boolean;
  onCreatePurchase?: (productId: number) => void;
  onViewAllAlerts?: () => void;
}

const LowStockAlert: React.FC<LowStockAlertProps> = ({ 
  items, 
  isLoading = false,
  onCreatePurchase = () => {},
  onViewAllAlerts = () => {}
}) => {
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Low Stock Alert</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-48 animate-pulse bg-gray-200 rounded"></div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader className="px-4 py-3 border-b border-gray-200 flex justify-between items-center">
        <CardTitle>Low Stock Alert</CardTitle>
        <Badge variant="destructive">{items.length} items</Badge>
      </CardHeader>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="bg-gray-50">
            <TableRow>
              <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Item Code</TableHead>
              <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Item Name</TableHead>
              <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Current Stock</TableHead>
              <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Min. Stock Level</TableHead>
              <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Last Restock</TableHead>
              <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.map((item) => (
              <TableRow key={item.id} className="hover:bg-blue-50">
                <TableCell className="text-sm text-gray-900">PR-{item.id.toString().padStart(3, '0')}</TableCell>
                <TableCell className="text-sm text-gray-900">{item.name}</TableCell>
                <TableCell className="text-sm text-red-600 font-medium">{item.currentStock} {item.unit}</TableCell>
                <TableCell className="text-sm text-gray-900">{item.minStockLevel} {item.unit}</TableCell>
                <TableCell className="text-sm text-gray-900">
                  {item.lastUpdated ? formatDate(item.lastUpdated) : 'N/A'}
                </TableCell>
                <TableCell className="text-sm">
                  <Button 
                    variant="link" 
                    className="text-blue-600 hover:underline p-0"
                    onClick={() => onCreatePurchase(item.id)}
                  >
                    Create Purchase
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      <CardFooter className="px-4 py-3 text-right border-t border-gray-200">
        <Button 
          variant="ghost" 
          className="text-blue-600 text-sm flex items-center ml-auto" 
          onClick={onViewAllAlerts}
        >
          <Eye className="h-4 w-4 mr-1" />
          View All Alerts
        </Button>
      </CardFooter>
    </Card>
  );
};

export default LowStockAlert;
