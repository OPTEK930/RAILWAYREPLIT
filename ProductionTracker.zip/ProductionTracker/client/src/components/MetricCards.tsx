import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Package, TrendingUp, ShoppingCart, BarChart } from 'lucide-react';
import { formatCurrency } from '@/lib/googleSheetsApi';

interface MetricCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  change: string;
  trend: 'up' | 'down';
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value, icon, change, trend }) => {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm text-gray-500">{title}</p>
            <h3 className="text-2xl font-medium mt-1">{value}</h3>
          </div>
          <div className="text-blue-500">
            {icon}
          </div>
        </div>
        <div className="flex items-center mt-2">
          <span className={`text-sm font-medium ${trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
            {change}
          </span>
          <span className="text-xs text-gray-500 ml-2">vs last period</span>
        </div>
      </CardContent>
    </Card>
  );
};

interface MetricCardsProps {
  metrics: {
    totalProduction: number;
    totalSales: number;
    purchaseCosts: number;
    currentInventory: number;
    productionChange: string;
    salesChange: string;
    purchaseChange: string;
    inventoryChange: string;
    productionTrend: 'up' | 'down';
    salesTrend: 'up' | 'down';
    purchaseTrend: 'up' | 'down';
    inventoryTrend: 'up' | 'down';
  };
  isLoading?: boolean;
}

const MetricCards: React.FC<MetricCardsProps> = ({ metrics, isLoading = false }) => {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {Array(4).fill(0).map((_, index) => (
          <Card key={index}>
            <CardContent className="p-4">
              <div className="h-20 animate-pulse bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      <MetricCard
        title="Total Production"
        value={`${metrics.totalProduction.toLocaleString()} units`}
        icon={<Package className="h-6 w-6" />}
        change={metrics.productionChange}
        trend={metrics.productionTrend}
      />
      <MetricCard
        title="Total Sales"
        value={formatCurrency(metrics.totalSales)}
        icon={<TrendingUp className="h-6 w-6 text-green-500" />}
        change={metrics.salesChange}
        trend={metrics.salesTrend}
      />
      <MetricCard
        title="Purchase Costs"
        value={formatCurrency(metrics.purchaseCosts)}
        icon={<ShoppingCart className="h-6 w-6 text-yellow-500" />}
        change={metrics.purchaseChange}
        trend={metrics.purchaseTrend}
      />
      <MetricCard
        title="Current Inventory"
        value={`${metrics.currentInventory.toLocaleString()} units`}
        icon={<BarChart className="h-6 w-6 text-gray-500" />}
        change={metrics.inventoryChange}
        trend={metrics.inventoryTrend}
      />
    </div>
  );
};

export default MetricCards;
