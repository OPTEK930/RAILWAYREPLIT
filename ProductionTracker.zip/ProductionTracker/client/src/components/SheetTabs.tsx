import React from 'react';
import { useLocation } from 'wouter';
import { cn } from '@/lib/utils';

interface Tab {
  name: string;
  path: string;
  label: string;
}

interface SheetTabsProps {
  tabs: Tab[];
}

const SheetTabs: React.FC<SheetTabsProps> = ({ tabs }) => {
  const [location, navigate] = useLocation();
  
  const getCurrentTab = () => {
    if (location === '/') return 'dashboard';
    return location.substring(1); // Remove the leading slash
  };
  
  return (
    <div className="sheet-tabs flex border-b border-gray-200 mb-6">
      {tabs.map((tab) => (
        <button
          key={tab.name}
          className={cn(
            "px-4 py-2 font-medium text-sm",
            getCurrentTab() === tab.name
              ? "text-blue-600 border-b-2 border-blue-600"
              : "text-gray-500 hover:text-gray-700 hover:border-gray-300"
          )}
          onClick={() => navigate(tab.path)}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
};

export default SheetTabs;
