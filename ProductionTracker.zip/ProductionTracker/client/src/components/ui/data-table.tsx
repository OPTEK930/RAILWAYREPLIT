import React from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Search, 
  Filter, 
  Download, 
  Edit, 
  Trash2 
} from 'lucide-react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface DataTableProps<T> {
  title: string;
  data: T[];
  columns: {
    key: string;
    header: string;
    cell: (item: T) => React.ReactNode;
  }[];
  isLoading?: boolean;
  totalCount?: number;
  currentPage?: number;
  searchValue?: string;
  onPageChange?: (page: number) => void;
  onSearch?: (value: string) => void;
  onEdit?: (item: T) => void;
  onDelete?: (item: T) => void;
  onFilter?: () => void;
  onExport?: () => void;
}

function DataTable<T extends { id: number }>({
  title,
  data,
  columns,
  isLoading = false,
  totalCount = 0,
  currentPage = 1,
  searchValue = '',
  onPageChange = () => {},
  onSearch = () => {},
  onEdit = () => {},
  onDelete = () => {},
  onFilter = () => {},
  onExport = () => {},
}: DataTableProps<T>) {
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>{title}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-96 animate-pulse bg-gray-200 rounded"></div>
        </CardContent>
      </Card>
    );
  }
  
  const itemsPerPage = 10;
  const totalPages = Math.ceil(totalCount / itemsPerPage);
  
  return (
    <Card>
      <CardHeader className="px-4 py-3 border-b border-gray-200 flex justify-between items-center">
        <CardTitle>{title}</CardTitle>
        <div className="flex items-center space-x-2">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search..."
              className="pl-8 pr-3 py-1 w-64"
              value={searchValue}
              onChange={(e) => onSearch(e.target.value)}
            />
            <Search className="h-4 w-4 text-gray-500 absolute left-2 top-1/2 transform -translate-y-1/2" />
          </div>
          <Button variant="outline" size="icon" onClick={onFilter}>
            <Filter className="h-4 w-4 text-gray-500" />
          </Button>
          <Button variant="outline" size="icon" onClick={onExport}>
            <Download className="h-4 w-4 text-gray-500" />
          </Button>
        </div>
      </CardHeader>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="bg-gray-50">
            <TableRow>
              {columns.map((column) => (
                <TableHead 
                  key={column.key} 
                  className="text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  {column.header}
                </TableHead>
              ))}
              <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((item) => (
              <TableRow key={item.id} className="hover:bg-blue-50">
                {columns.map((column) => (
                  <TableCell key={`${item.id}-${column.key}`} className="text-sm text-gray-900">
                    {column.cell(item)}
                  </TableCell>
                ))}
                <TableCell className="text-sm">
                  <div className="flex space-x-1">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-blue-600 hover:bg-gray-100 rounded"
                      onClick={() => onEdit(item)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-red-600 hover:bg-gray-100 rounded"
                      onClick={() => onDelete(item)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      <CardFooter className="px-4 py-3 border-t border-gray-200 flex justify-between items-center">
        <span className="text-sm text-gray-500">
          Showing {data.length} of {totalCount} entries
        </span>
        <div className="flex items-center space-x-1">
          <Button
            variant="ghost"
            size="icon"
            disabled={currentPage === 1}
            onClick={() => onPageChange(currentPage - 1)}
            className={currentPage === 1 ? 'opacity-50 cursor-not-allowed' : ''}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          {Array.from({ length: Math.min(3, totalPages) }, (_, i) => (
            <Button
              key={i}
              variant={currentPage === i + 1 ? 'default' : 'ghost'}
              size="sm"
              onClick={() => onPageChange(i + 1)}
              className={`px-3 py-1 ${
                currentPage === i + 1 ? 'bg-blue-500 text-white' : ''
              }`}
            >
              {i + 1}
            </Button>
          ))}
          <Button
            variant="ghost"
            size="icon"
            disabled={currentPage === totalPages}
            onClick={() => onPageChange(currentPage + 1)}
            className={currentPage === totalPages ? 'opacity-50 cursor-not-allowed' : ''}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}

export { DataTable };
