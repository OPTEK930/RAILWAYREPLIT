import { apiRequest } from "@/lib/queryClient";

// This file provides utility functions for interacting with the Google Sheets API via our backend
// Note: The actual implementation would require setting up Google Sheets API in a real production environment

export async function exportToSheet(
  data: any[],
  sheetName: string
): Promise<boolean> {
  try {
    // This would typically call the backend which would handle the Google Sheets API interaction
    const response = await apiRequest('POST', `/api/export/${sheetName}`, { data });
    return response.ok;
  } catch (error) {
    console.error("Failed to export data to Google Sheets:", error);
    return false;
  }
}

export async function importFromSheet(sheetName: string): Promise<any[]> {
  try {
    // This would typically call the backend which would handle the Google Sheets API interaction
    const response = await apiRequest('GET', `/api/import/${sheetName}`);
    return await response.json();
  } catch (error) {
    console.error("Failed to import data from Google Sheets:", error);
    return [];
  }
}

// Function to format currency values
export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2
  }).format(value);
}

// Function to format dates
export function formatDate(date: Date | string): string {
  if (typeof date === 'string') {
    date = new Date(date);
  }
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  });
}

// Function to calculate percentage change
export function calculatePercentageChange(current: number, previous: number): string {
  if (previous === 0) return "0%";
  
  const change = ((current - previous) / Math.abs(previous)) * 100;
  const sign = change >= 0 ? '↑' : '↓';
  return `${sign} ${Math.abs(change).toFixed(1)}%`;
}
