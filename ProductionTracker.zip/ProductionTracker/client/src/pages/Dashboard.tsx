import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { RefreshCw, BarChart3, PieChart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import MetricCards from '@/components/MetricCards';
import ActivityTable from '@/components/ActivityTable';
import LowStockAlert from '@/components/LowStockAlert';
import SheetTabs from '@/components/SheetTabs';
import { Activity, Metric } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { calculatePercentageChange } from '@/lib/googleSheetsApi';

const tabs = [
  { name: 'dashboard', path: '/', label: 'Dashboard' },
  { name: 'production', path: '/production', label: 'Production Log' },
  { name: 'sales', path: '/sales', label: 'Sales Log' },
  { name: 'purchases', path: '/purchases', label: 'Purchases' },
  { name: 'inventory', path: '/inventory', label: 'Inventory' },
];

const Dashboard: React.FC = () => {
  const { toast } = useToast();
  const [dateRange, setDateRange] = useState('last30');
  const [activitiesPage, setActivitiesPage] = useState(1);
  
  const { data: metrics, isLoading: isLoadingMetrics } = useQuery<Metric>({
    queryKey: ['/api/metrics'],
  });
  
  const { data: activities, isLoading: isLoadingActivities } = useQuery<Activity[]>({
    queryKey: ['/api/activities', { limit: 5 }],
  });
  
  const { data: lowStockItems, isLoading: isLoadingLowStock } = useQuery<any[]>({
    queryKey: ['/api/low-stock'],
  });
  
  const handleCreatePurchase = (productId: number) => {
    // Navigate to purchases page with this product pre-selected
    window.location.href = `/purchases?productId=${productId}`;
  };
  
  const handleViewAllAlerts = () => {
    // Navigate to inventory page with low stock filter
    window.location.href = '/inventory?filter=lowStock';
  };
  
  const transformedMetrics = metrics ? {
    totalProduction: metrics.totalProduction,
    totalSales: Number(metrics.totalSales),
    purchaseCosts: Number(metrics.purchaseCosts),
    currentInventory: metrics.currentInventory,
    productionChange: calculatePercentageChange(metrics.totalProduction, metrics.totalProduction * 0.92),
    salesChange: calculatePercentageChange(Number(metrics.totalSales), Number(metrics.totalSales) * 0.875),
    purchaseChange: calculatePercentageChange(Number(metrics.purchaseCosts), Number(metrics.purchaseCosts) * 0.95),
    inventoryChange: calculatePercentageChange(metrics.currentInventory, metrics.currentInventory * 1.02),
    productionTrend: 'up' as const,
    salesTrend: 'up' as const,
    purchaseTrend: 'up' as const,
    inventoryTrend: 'down' as const,
  } : {
    totalProduction: 0,
    totalSales: 0,
    purchaseCosts: 0,
    currentInventory: 0,
    productionChange: '0%',
    salesChange: '0%',
    purchaseChange: '0%',
    inventoryChange: '0%',
    productionTrend: 'up' as const,
    salesTrend: 'up' as const,
    purchaseTrend: 'up' as const,
    inventoryTrend: 'up' as const,
  };
  
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <SheetTabs tabs={tabs} />
      
      <div className="pb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-medium text-gray-900">Dashboard Overview</h2>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-500">Date Range:</span>
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="border border-gray-200 rounded px-3 py-1 text-sm bg-white w-40">
                <SelectValue placeholder="Select date range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="last30">Last 30 days</SelectItem>
                <SelectItem value="thisMonth">This month</SelectItem>
                <SelectItem value="lastMonth">Last month</SelectItem>
                <SelectItem value="thisQuarter">This quarter</SelectItem>
                <SelectItem value="custom">Custom...</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <MetricCards metrics={transformedMetrics} isLoading={isLoadingMetrics} />
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-base font-medium">Production vs Sales Trend</CardTitle>
              <Select defaultValue="last12Months">
                <SelectTrigger className="border border-gray-200 rounded px-2 py-1 text-sm bg-white w-40 h-8">
                  <SelectValue placeholder="Select period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="last12Months">Last 12 months</SelectItem>
                  <SelectItem value="last30Days">Last 30 days</SelectItem>
                  <SelectItem value="last7Days">Last 7 days</SelectItem>
                </SelectContent>
              </Select>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center bg-gray-100 rounded">
                <div className="text-center">
                  <BarChart3 className="h-12 w-12 text-gray-300 mx-auto" />
                  <p className="text-sm text-gray-500 mt-2">Production vs Sales Chart</p>
                  <p className="text-xs text-gray-500">Line chart showing production and sales trends over time</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-base font-medium">Inventory Status</CardTitle>
              <Button variant="ghost" size="sm" className="h-8 text-blue-600 text-sm flex items-center">
                <RefreshCw className="h-4 w-4 mr-1" />
                Refresh
              </Button>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center bg-gray-100 rounded">
                <div className="text-center">
                  <PieChart className="h-12 w-12 text-gray-300 mx-auto" />
                  <p className="text-sm text-gray-500 mt-2">Inventory Status Chart</p>
                  <p className="text-xs text-gray-500">Pie chart showing inventory levels by category</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="mb-8">
          <ActivityTable 
            activities={activities || []} 
            isLoading={isLoadingActivities}
            totalCount={activities?.length || 0}
            currentPage={activitiesPage}
            onPageChange={setActivitiesPage}
          />
        </div>
        
        <div>
          <LowStockAlert 
            items={lowStockItems || []} 
            isLoading={isLoadingLowStock}
            onCreatePurchase={handleCreatePurchase}
            onViewAllAlerts={handleViewAllAlerts}
          />
        </div>
      </div>
    </main>
  );
};

export default Dashboard;
