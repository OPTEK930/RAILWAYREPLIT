import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle
} from '@/components/ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { AlertTriangle, Download, Filter, Search } from 'lucide-react';
import SheetTabs from '@/components/SheetTabs';
import { formatDate } from '@/lib/googleSheetsApi';
import { Product, Inventory } from '@shared/schema';

const tabs = [
  { name: 'dashboard', path: '/', label: 'Dashboard' },
  { name: 'production', path: '/production', label: 'Production Log' },
  { name: 'sales', path: '/sales', label: 'Sales Log' },
  { name: 'purchases', path: '/purchases', label: 'Purchases' },
  { name: 'inventory', path: '/inventory', label: 'Inventory' },
];

interface InventoryItemWithDetails extends Inventory {
  product?: Product;
  status: 'Normal' | 'Low' | 'Out of Stock';
}

const InventoryPage: React.FC = () => {
  const [, navigate] = useLocation();
  const [searchValue, setSearchValue] = useState('');
  const [filterValue, setFilterValue] = useState('all');
  
  // Parse URL query parameters
  const params = new URLSearchParams(location.search);
  const urlFilter = params.get('filter');
  
  // Set filter from URL parameter if present
  React.useEffect(() => {
    if (urlFilter === 'lowStock') {
      setFilterValue('low');
    }
  }, [urlFilter]);
  
  // Fetch inventory data
  const { data: inventory, isLoading: isLoadingInventory } = useQuery<Inventory[]>({
    queryKey: ['/api/inventory'],
  });
  
  // Fetch products data
  const { data: products, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });
  
  const isLoading = isLoadingInventory || isLoadingProducts;
  
  // Process inventory data to include product details and status
  const inventoryWithDetails: InventoryItemWithDetails[] = React.useMemo(() => {
    if (!inventory || !products) return [];
    
    return inventory.map(item => {
      const product = products.find(p => p.id === item.productId);
      
      let status: 'Normal' | 'Low' | 'Out of Stock' = 'Normal';
      if (item.quantity === 0) {
        status = 'Out of Stock';
      } else if (product && item.quantity < product.minStockLevel) {
        status = 'Low';
      }
      
      return {
        ...item,
        product,
        status
      };
    });
  }, [inventory, products]);
  
  // Filter inventory based on search and filter values
  const filteredInventory = React.useMemo(() => {
    return inventoryWithDetails.filter(item => {
      // Apply search filter
      const searchMatch = 
        !searchValue || 
        item.product?.name.toLowerCase().includes(searchValue.toLowerCase()) ||
        item.product?.description?.toLowerCase().includes(searchValue.toLowerCase());
      
      // Apply status filter
      const filterMatch = 
        filterValue === 'all' || 
        (filterValue === 'low' && item.status === 'Low') || 
        (filterValue === 'out' && item.status === 'Out of Stock');
      
      return searchMatch && filterMatch;
    });
  }, [inventoryWithDetails, searchValue, filterValue]);
  
  // Handle create purchase button click
  const handleCreatePurchase = (productId: number) => {
    navigate(`/purchases?productId=${productId}`);
  };
  
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <SheetTabs tabs={tabs} />
      
      <Card>
        <CardHeader className="px-4 py-3 border-b border-gray-200 flex justify-between items-center">
          <CardTitle>Inventory</CardTitle>
          <div className="flex items-center space-x-2">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search..."
                className="pl-8 pr-3 py-1 w-64"
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
              />
              <Search className="h-4 w-4 text-gray-500 absolute left-2 top-1/2 transform -translate-y-1/2" />
            </div>
            <Select value={filterValue} onValueChange={setFilterValue}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Items</SelectItem>
                <SelectItem value="low">Low Stock</SelectItem>
                <SelectItem value="out">Out of Stock</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4 text-gray-500" />
            </Button>
            <Button variant="outline" size="icon">
              <Download className="h-4 w-4 text-gray-500" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
            </div>
          ) : filteredInventory.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center p-4">
              <AlertTriangle className="h-12 w-12 text-gray-300 mb-2" />
              <h3 className="text-lg font-medium text-gray-900">No inventory items found</h3>
              <p className="text-sm text-gray-500 mt-1">
                {searchValue || filterValue !== 'all'
                  ? "Try adjusting your search or filter criteria"
                  : "Start by adding products and recording production or purchases"}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-gray-50">
                  <TableRow>
                    <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Item Code</TableHead>
                    <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Product Name</TableHead>
                    <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Description</TableHead>
                    <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Current Stock</TableHead>
                    <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Min. Stock Level</TableHead>
                    <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Status</TableHead>
                    <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Last Updated</TableHead>
                    <TableHead className="text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredInventory.map((item) => (
                    <TableRow key={item.id} className="hover:bg-blue-50">
                      <TableCell className="text-sm text-gray-900">
                        PR-{item.productId.toString().padStart(3, '0')}
                      </TableCell>
                      <TableCell className="text-sm text-gray-900">
                        {item.product?.name || 'Unknown Product'}
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {item.product?.description || 'No description'}
                      </TableCell>
                      <TableCell className={`text-sm font-medium ${
                        item.status === 'Low' ? 'text-yellow-600' : 
                        item.status === 'Out of Stock' ? 'text-red-600' : 
                        'text-gray-900'
                      }`}>
                        {item.quantity} {item.product?.unit || 'units'}
                      </TableCell>
                      <TableCell className="text-sm text-gray-900">
                        {item.product?.minStockLevel || 0} {item.product?.unit || 'units'}
                      </TableCell>
                      <TableCell className="text-sm">
                        <Badge 
                          className={
                            item.status === 'Normal' ? 'bg-green-100 text-green-800' : 
                            item.status === 'Low' ? 'bg-yellow-100 text-yellow-800' : 
                            'bg-red-100 text-red-800'
                          } 
                          variant="outline"
                        >
                          {item.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-gray-900">
                        {formatDate(item.lastUpdated)}
                      </TableCell>
                      <TableCell className="text-sm">
                        {(item.status === 'Low' || item.status === 'Out of Stock') && (
                          <Button 
                            variant="link" 
                            className="text-blue-600 hover:underline p-0"
                            onClick={() => handleCreatePurchase(item.productId)}
                          >
                            Create Purchase
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </main>
  );
};

export default InventoryPage;
