import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DataTable } from '@/components/ui/data-table';
import SheetTabs from '@/components/SheetTabs';
import { formatCurrency, formatDate } from '@/lib/googleSheetsApi';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Product, InsertProductionLog, type ProductionLog } from '@shared/schema';

const tabs = [
  { name: 'dashboard', path: '/', label: 'Dashboard' },
  { name: 'production', path: '/production', label: 'Production Log' },
  { name: 'sales', path: '/sales', label: 'Sales Log' },
  { name: 'purchases', path: '/purchases', label: 'Purchases' },
  { name: 'inventory', path: '/inventory', label: 'Inventory' },
];

// Form validation schema
const productionFormSchema = z.object({
  date: z.string().min(1, "Date is required"),
  productId: z.number().min(1, "Product is required"),
  batchNumber: z.string().min(1, "Batch number is required"),
  quantity: z.number().min(1, "Quantity must be at least 1"),
  unitCost: z.number().min(0.01, "Unit cost must be greater than 0"),
  status: z.string().min(1, "Status is required"),
  notes: z.string().optional(),
});

type ProductionFormValues = z.infer<typeof productionFormSchema>;

const ProductionLogPage: React.FC = () => {
  const { toast } = useToast();
  const [currentPage, setCurrentPage] = useState(1);
  const [searchValue, setSearchValue] = useState('');
  const [editingId, setEditingId] = useState<number | null>(null);
  
  // Fetch production logs
  const { data: productionLogs, isLoading: isLoadingLogs } = useQuery<ProductionLog[]>({
    queryKey: ['/api/production-logs'],
  });
  
  // Fetch products for dropdown
  const { data: products, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });
  
  // Form setup
  const form = useForm<ProductionFormValues>({
    resolver: zodResolver(productionFormSchema),
    defaultValues: {
      date: format(new Date(), 'yyyy-MM-dd'),
      productId: 0,
      batchNumber: `BATCH-${format(new Date(), 'yyyy')}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
      quantity: 0,
      unitCost: 0,
      status: 'In Progress',
      notes: '',
    },
  });
  
  // Create production log mutation
  const createMutation = useMutation({
    mutationFn: async (data: ProductionFormValues) => {
      return await apiRequest('POST', '/api/production-logs', data);
    },
    onSuccess: () => {
      toast({
        title: "Production Entry Added",
        description: "The production entry has been successfully added.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/production-logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add production entry: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Update production log mutation
  const updateMutation = useMutation({
    mutationFn: async (data: ProductionFormValues & { id: number }) => {
      const { id, ...updateData } = data;
      return await apiRequest('PUT', `/api/production-logs/${id}`, updateData);
    },
    onSuccess: () => {
      toast({
        title: "Production Entry Updated",
        description: "The production entry has been successfully updated.",
      });
      form.reset();
      setEditingId(null);
      queryClient.invalidateQueries({ queryKey: ['/api/production-logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update production entry: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Delete production log mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest('DELETE', `/api/production-logs/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Production Entry Deleted",
        description: "The production entry has been successfully deleted.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/production-logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete production entry: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Form submission handler
  const onSubmit = (values: ProductionFormValues) => {
    if (editingId !== null) {
      updateMutation.mutate({ ...values, id: editingId });
    } else {
      createMutation.mutate(values);
    }
  };
  
  // Handle edit button click
  const handleEdit = (log: ProductionLog) => {
    setEditingId(log.id);
    form.reset({
      date: format(new Date(log.date), 'yyyy-MM-dd'),
      productId: log.productId,
      batchNumber: log.batchNumber,
      quantity: Number(log.quantity),
      unitCost: Number(log.unitCost),
      status: log.status,
      notes: log.notes || '',
    });
  };
  
  // Handle delete button click
  const handleDelete = (log: ProductionLog) => {
    if (confirm('Are you sure you want to delete this production entry?')) {
      deleteMutation.mutate(log.id);
    }
  };
  
  // Handle cancel button click
  const handleCancel = () => {
    form.reset();
    setEditingId(null);
  };
  
  // Table columns
  const columns = [
    {
      key: 'date',
      header: 'Date',
      cell: (log: ProductionLog) => formatDate(log.date as string),
    },
    {
      key: 'product',
      header: 'Product',
      cell: (log: ProductionLog) => {
        const product = products?.find(p => p.id === log.productId);
        return product?.name || 'Unknown Product';
      },
    },
    {
      key: 'batchNumber',
      header: 'Batch #',
      cell: (log: ProductionLog) => log.batchNumber,
    },
    {
      key: 'quantity',
      header: 'Quantity',
      cell: (log: ProductionLog) => {
        const product = products?.find(p => p.id === log.productId);
        return `${log.quantity} ${product?.unit || 'units'}`;
      },
    },
    {
      key: 'unitCost',
      header: 'Unit Cost',
      cell: (log: ProductionLog) => formatCurrency(Number(log.unitCost)),
    },
    {
      key: 'totalCost',
      header: 'Total Cost',
      cell: (log: ProductionLog) => formatCurrency(Number(log.totalCost)),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (log: ProductionLog) => {
        const statusColors: Record<string, string> = {
          'In Progress': 'bg-blue-100 text-blue-800',
          'Completed': 'bg-green-100 text-green-800',
          'Quality Check': 'bg-yellow-100 text-yellow-800',
          'Rejected': 'bg-red-100 text-red-800',
        };
        
        return (
          <Badge className={statusColors[log.status] || 'bg-gray-100 text-gray-800'} variant="outline">
            {log.status}
          </Badge>
        );
      },
    },
  ];
  
  const isLoading = isLoadingLogs || isLoadingProducts;
  const isPending = createMutation.isPending || updateMutation.isPending || deleteMutation.isPending;
  
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <SheetTabs tabs={tabs} />
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>{editingId ? 'Edit Production Entry' : 'Add Production Entry'}</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Production Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="productId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Product</FormLabel>
                    <Select
                      value={field.value ? field.value.toString() : ""}
                      onValueChange={(value) => field.onChange(parseInt(value))}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Product" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {products?.map((product) => (
                          <SelectItem key={product.id} value={product.id.toString()}>
                            {product.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="batchNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Batch Number</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. BATCH-2023-001" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity Produced</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        min="0"
                        placeholder="0"
                        {...field}
                        onChange={(e) => field.onChange(e.target.valueAsNumber)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="unitCost"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Unit Cost</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        min="0"
                        step="0.01"
                        placeholder="0.00"
                        {...field}
                        onChange={(e) => field.onChange(e.target.valueAsNumber)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Production Status</FormLabel>
                    <Select
                      value={field.value}
                      onValueChange={field.onChange}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="Completed">Completed</SelectItem>
                        <SelectItem value="Quality Check">Quality Check</SelectItem>
                        <SelectItem value="Rejected">Rejected</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem className="md:col-span-2 lg:col-span-3">
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Add any additional notes here"
                        className="resize-none" 
                        rows={2}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="md:col-span-2 lg:col-span-3 flex justify-end space-x-3">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={handleCancel}
                  disabled={isPending}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={isPending}
                >
                  {isPending ? 'Processing...' : editingId ? 'Update Production Entry' : 'Add Production Entry'}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
      
      <DataTable
        title="Production Log"
        data={productionLogs || []}
        columns={columns}
        isLoading={isLoading}
        totalCount={productionLogs?.length || 0}
        currentPage={currentPage}
        searchValue={searchValue}
        onPageChange={setCurrentPage}
        onSearch={setSearchValue}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onFilter={() => {}}
        onExport={() => {}}
      />
    </main>
  );
};

export default ProductionLogPage;
