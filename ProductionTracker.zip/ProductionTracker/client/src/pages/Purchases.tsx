import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DataTable } from '@/components/ui/data-table';
import SheetTabs from '@/components/SheetTabs';
import { formatCurrency, formatDate } from '@/lib/googleSheetsApi';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';
import { Product, InsertPurchase, Purchase } from '@shared/schema';

const tabs = [
  { name: 'dashboard', path: '/', label: 'Dashboard' },
  { name: 'production', path: '/production', label: 'Production Log' },
  { name: 'sales', path: '/sales', label: 'Sales Log' },
  { name: 'purchases', path: '/purchases', label: 'Purchases' },
  { name: 'inventory', path: '/inventory', label: 'Inventory' },
];

// Form validation schema
const purchaseFormSchema = z.object({
  date: z.string().min(1, "Date is required"),
  orderNumber: z.string().min(1, "Order number is required"),
  supplierName: z.string().min(1, "Supplier name is required"),
  productId: z.number().min(1, "Product is required"),
  quantity: z.number().min(1, "Quantity must be at least 1"),
  unitCost: z.number().min(0.01, "Unit cost must be greater than 0"),
  status: z.string().min(1, "Status is required"),
  notes: z.string().optional(),
});

type PurchaseFormValues = z.infer<typeof purchaseFormSchema>;

const Purchases: React.FC = () => {
  const { toast } = useToast();
  const [location] = useLocation();
  const [currentPage, setCurrentPage] = useState(1);
  const [searchValue, setSearchValue] = useState('');
  const [editingId, setEditingId] = useState<number | null>(null);
  
  // Parse URL query parameters to check if a product is pre-selected
  const params = new URLSearchParams(location.split('?')[1] || '');
  const productIdParam = params.get('productId');
  
  // Fetch purchases
  const { data: purchases, isLoading: isLoadingPurchases } = useQuery<Purchase[]>({
    queryKey: ['/api/purchases'],
  });
  
  // Fetch products for dropdown
  const { data: products, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });
  
  // Form setup
  const form = useForm<PurchaseFormValues>({
    resolver: zodResolver(purchaseFormSchema),
    defaultValues: {
      date: format(new Date(), 'yyyy-MM-dd'),
      orderNumber: `PO-${format(new Date(), 'yyyyMMdd')}-${Math.floor(Math.random() * 100).toString().padStart(3, '0')}`,
      supplierName: '',
      productId: productIdParam ? parseInt(productIdParam) : 0,
      quantity: 0,
      unitCost: 0,
      status: 'Ordered',
      notes: '',
    },
  });
  
  // Update the form if product ID from query parameter becomes available
  useEffect(() => {
    if (productIdParam) {
      form.setValue('productId', parseInt(productIdParam));
    }
  }, [productIdParam, form]);
  
  // Create purchase mutation
  const createMutation = useMutation({
    mutationFn: async (data: PurchaseFormValues) => {
      return await apiRequest('POST', '/api/purchases', data);
    },
    onSuccess: () => {
      toast({
        title: "Purchase Order Added",
        description: "The purchase order has been successfully added.",
      });
      form.reset({
        date: format(new Date(), 'yyyy-MM-dd'),
        orderNumber: `PO-${format(new Date(), 'yyyyMMdd')}-${Math.floor(Math.random() * 100).toString().padStart(3, '0')}`,
        supplierName: '',
        productId: 0,
        quantity: 0,
        unitCost: 0,
        status: 'Ordered',
        notes: '',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/purchases'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      // Only invalidate inventory if the status is Received
      if (form.getValues('status') === 'Received') {
        queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
      }
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add purchase order: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Update purchase mutation
  const updateMutation = useMutation({
    mutationFn: async (data: PurchaseFormValues & { id: number }) => {
      const { id, ...updateData } = data;
      return await apiRequest('PUT', `/api/purchases/${id}`, updateData);
    },
    onSuccess: () => {
      toast({
        title: "Purchase Order Updated",
        description: "The purchase order has been successfully updated.",
      });
      form.reset();
      setEditingId(null);
      queryClient.invalidateQueries({ queryKey: ['/api/purchases'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update purchase order: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Delete purchase mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest('DELETE', `/api/purchases/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Purchase Order Deleted",
        description: "The purchase order has been successfully deleted.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/purchases'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete purchase order: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Form submission handler
  const onSubmit = (values: PurchaseFormValues) => {
    if (editingId !== null) {
      updateMutation.mutate({ ...values, id: editingId });
    } else {
      createMutation.mutate(values);
    }
  };
  
  // Handle edit button click
  const handleEdit = (purchase: Purchase) => {
    setEditingId(purchase.id);
    form.reset({
      date: format(new Date(purchase.date), 'yyyy-MM-dd'),
      orderNumber: purchase.orderNumber,
      supplierName: purchase.supplierName,
      productId: purchase.productId,
      quantity: Number(purchase.quantity),
      unitCost: Number(purchase.unitCost),
      status: purchase.status,
      notes: purchase.notes || '',
    });
  };
  
  // Handle delete button click
  const handleDelete = (purchase: Purchase) => {
    if (confirm('Are you sure you want to delete this purchase order?')) {
      deleteMutation.mutate(purchase.id);
    }
  };
  
  // Handle cancel button click
  const handleCancel = () => {
    form.reset();
    setEditingId(null);
  };
  
  // Table columns
  const columns = [
    {
      key: 'date',
      header: 'Date',
      cell: (purchase: Purchase) => formatDate(purchase.date as string),
    },
    {
      key: 'orderNumber',
      header: 'Order #',
      cell: (purchase: Purchase) => purchase.orderNumber,
    },
    {
      key: 'supplierName',
      header: 'Supplier',
      cell: (purchase: Purchase) => purchase.supplierName,
    },
    {
      key: 'product',
      header: 'Product',
      cell: (purchase: Purchase) => {
        const product = products?.find(p => p.id === purchase.productId);
        return product?.name || 'Unknown Product';
      },
    },
    {
      key: 'quantity',
      header: 'Quantity',
      cell: (purchase: Purchase) => {
        const product = products?.find(p => p.id === purchase.productId);
        return `${purchase.quantity} ${product?.unit || 'units'}`;
      },
    },
    {
      key: 'unitCost',
      header: 'Unit Cost',
      cell: (purchase: Purchase) => formatCurrency(Number(purchase.unitCost)),
    },
    {
      key: 'totalCost',
      header: 'Total Cost',
      cell: (purchase: Purchase) => formatCurrency(Number(purchase.totalCost)),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (purchase: Purchase) => {
        const statusColors: Record<string, string> = {
          'Ordered': 'bg-blue-100 text-blue-800',
          'Processing': 'bg-yellow-100 text-yellow-800',
          'Received': 'bg-green-100 text-green-800',
          'Cancelled': 'bg-red-100 text-red-800',
        };
        
        return (
          <Badge className={statusColors[purchase.status] || 'bg-gray-100 text-gray-800'} variant="outline">
            {purchase.status}
          </Badge>
        );
      },
    },
  ];
  
  const isLoading = isLoadingPurchases || isLoadingProducts;
  const isPending = createMutation.isPending || updateMutation.isPending || deleteMutation.isPending;
  
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <SheetTabs tabs={tabs} />
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>{editingId ? 'Edit Purchase Order' : 'Add Purchase Order'}</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Purchase Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="orderNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Order Number</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. PO-20230615-001" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="supplierName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Supplier Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter supplier name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="productId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Product</FormLabel>
                    <Select
                      value={field.value ? field.value.toString() : ""}
                      onValueChange={(value) => field.onChange(parseInt(value))}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Product" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {products?.map((product) => (
                          <SelectItem key={product.id} value={product.id.toString()}>
                            {product.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        min="0"
                        placeholder="0"
                        {...field}
                        onChange={(e) => field.onChange(e.target.valueAsNumber)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="unitCost"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Unit Cost</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        min="0"
                        step="0.01"
                        placeholder="0.00"
                        {...field}
                        onChange={(e) => field.onChange(e.target.valueAsNumber)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select
                      value={field.value}
                      onValueChange={field.onChange}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Ordered">Ordered</SelectItem>
                        <SelectItem value="Processing">Processing</SelectItem>
                        <SelectItem value="Received">Received</SelectItem>
                        <SelectItem value="Cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem className="md:col-span-2 lg:col-span-3">
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Add any additional notes here"
                        className="resize-none" 
                        rows={2}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="md:col-span-2 lg:col-span-3 flex justify-end space-x-3">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={handleCancel}
                  disabled={isPending}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={isPending}
                >
                  {isPending ? 'Processing...' : editingId ? 'Update Purchase Order' : 'Add Purchase Order'}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
      
      <DataTable
        title="Purchases"
        data={purchases || []}
        columns={columns}
        isLoading={isLoading}
        totalCount={purchases?.length || 0}
        currentPage={currentPage}
        searchValue={searchValue}
        onPageChange={setCurrentPage}
        onSearch={setSearchValue}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onFilter={() => {}}
        onExport={() => {}}
      />
    </main>
  );
};

export default Purchases;
