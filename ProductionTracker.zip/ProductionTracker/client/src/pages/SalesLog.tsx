import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DataTable } from '@/components/ui/data-table';
import SheetTabs from '@/components/SheetTabs';
import { formatCurrency, formatDate } from '@/lib/googleSheetsApi';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Product, InsertSalesLog, type SalesLog } from '@shared/schema';

const tabs = [
  { name: 'dashboard', path: '/', label: 'Dashboard' },
  { name: 'production', path: '/production', label: 'Production Log' },
  { name: 'sales', path: '/sales', label: 'Sales Log' },
  { name: 'purchases', path: '/purchases', label: 'Purchases' },
  { name: 'inventory', path: '/inventory', label: 'Inventory' },
];

// Form validation schema
const salesFormSchema = z.object({
  date: z.string().min(1, "Date is required"),
  invoiceNumber: z.string().min(1, "Invoice number is required"),
  customerName: z.string().min(1, "Customer name is required"),
  productId: z.number().min(1, "Product is required"),
  quantity: z.number().min(1, "Quantity must be at least 1"),
  unitPrice: z.number().min(0.01, "Unit price must be greater than 0"),
  status: z.string().min(1, "Status is required"),
  notes: z.string().optional(),
});

type SalesFormValues = z.infer<typeof salesFormSchema>;

const SalesLogPage: React.FC = () => {
  const { toast } = useToast();
  const [currentPage, setCurrentPage] = useState(1);
  const [searchValue, setSearchValue] = useState('');
  const [editingId, setEditingId] = useState<number | null>(null);
  
  // Fetch sales logs
  const { data: salesLogs, isLoading: isLoadingLogs } = useQuery<SalesLog[]>({
    queryKey: ['/api/sales-logs'],
  });
  
  // Fetch products for dropdown
  const { data: products, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });
  
  // Form setup
  const form = useForm<SalesFormValues>({
    resolver: zodResolver(salesFormSchema),
    defaultValues: {
      date: format(new Date(), 'yyyy-MM-dd'),
      invoiceNumber: `INV-${format(new Date(), 'yyyyMMdd')}-${Math.floor(Math.random() * 100).toString().padStart(3, '0')}`,
      customerName: '',
      productId: 0,
      quantity: 0,
      unitPrice: 0,
      status: 'Pending',
      notes: '',
    },
  });
  
  // Create sales log mutation
  const createMutation = useMutation({
    mutationFn: async (data: SalesFormValues) => {
      return await apiRequest('POST', '/api/sales-logs', data);
    },
    onSuccess: () => {
      toast({
        title: "Sales Entry Added",
        description: "The sales entry has been successfully added.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/sales-logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add sales entry: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Update sales log mutation
  const updateMutation = useMutation({
    mutationFn: async (data: SalesFormValues & { id: number }) => {
      const { id, ...updateData } = data;
      return await apiRequest('PUT', `/api/sales-logs/${id}`, updateData);
    },
    onSuccess: () => {
      toast({
        title: "Sales Entry Updated",
        description: "The sales entry has been successfully updated.",
      });
      form.reset();
      setEditingId(null);
      queryClient.invalidateQueries({ queryKey: ['/api/sales-logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update sales entry: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Delete sales log mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest('DELETE', `/api/sales-logs/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Sales Entry Deleted",
        description: "The sales entry has been successfully deleted.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/sales-logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete sales entry: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Form submission handler
  const onSubmit = (values: SalesFormValues) => {
    if (editingId !== null) {
      updateMutation.mutate({ ...values, id: editingId });
    } else {
      createMutation.mutate(values);
    }
  };
  
  // Handle edit button click
  const handleEdit = (log: SalesLog) => {
    setEditingId(log.id);
    form.reset({
      date: format(new Date(log.date), 'yyyy-MM-dd'),
      invoiceNumber: log.invoiceNumber,
      customerName: log.customerName,
      productId: log.productId,
      quantity: Number(log.quantity),
      unitPrice: Number(log.unitPrice),
      status: log.status,
      notes: log.notes || '',
    });
  };
  
  // Handle delete button click
  const handleDelete = (log: SalesLog) => {
    if (confirm('Are you sure you want to delete this sales entry?')) {
      deleteMutation.mutate(log.id);
    }
  };
  
  // Handle cancel button click
  const handleCancel = () => {
    form.reset();
    setEditingId(null);
  };
  
  // Table columns
  const columns = [
    {
      key: 'date',
      header: 'Date',
      cell: (log: SalesLog) => formatDate(log.date as string),
    },
    {
      key: 'invoiceNumber',
      header: 'Invoice #',
      cell: (log: SalesLog) => log.invoiceNumber,
    },
    {
      key: 'customerName',
      header: 'Customer',
      cell: (log: SalesLog) => log.customerName,
    },
    {
      key: 'product',
      header: 'Product',
      cell: (log: SalesLog) => {
        const product = products?.find(p => p.id === log.productId);
        return product?.name || 'Unknown Product';
      },
    },
    {
      key: 'quantity',
      header: 'Quantity',
      cell: (log: SalesLog) => {
        const product = products?.find(p => p.id === log.productId);
        return `${log.quantity} ${product?.unit || 'units'}`;
      },
    },
    {
      key: 'unitPrice',
      header: 'Unit Price',
      cell: (log: SalesLog) => formatCurrency(Number(log.unitPrice)),
    },
    {
      key: 'totalAmount',
      header: 'Total Amount',
      cell: (log: SalesLog) => formatCurrency(Number(log.totalAmount)),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (log: SalesLog) => {
        const statusColors: Record<string, string> = {
          'Pending': 'bg-yellow-100 text-yellow-800',
          'Paid': 'bg-green-100 text-green-800',
          'Overdue': 'bg-red-100 text-red-800',
          'Cancelled': 'bg-gray-100 text-gray-800',
        };
        
        return (
          <Badge className={statusColors[log.status] || 'bg-gray-100 text-gray-800'} variant="outline">
            {log.status}
          </Badge>
        );
      },
    },
  ];
  
  const isLoading = isLoadingLogs || isLoadingProducts;
  const isPending = createMutation.isPending || updateMutation.isPending || deleteMutation.isPending;
  
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <SheetTabs tabs={tabs} />
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>{editingId ? 'Edit Sales Entry' : 'Add Sales Entry'}</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Sale Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="invoiceNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Invoice Number</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. INV-20230615-001" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="customerName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Customer Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter customer name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="productId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Product</FormLabel>
                    <Select
                      value={field.value ? field.value.toString() : ""}
                      onValueChange={(value) => field.onChange(parseInt(value))}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Product" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {products?.map((product) => (
                          <SelectItem key={product.id} value={product.id.toString()}>
                            {product.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        min="0"
                        placeholder="0"
                        {...field}
                        onChange={(e) => field.onChange(e.target.valueAsNumber)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="unitPrice"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Unit Price</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        min="0"
                        step="0.01"
                        placeholder="0.00"
                        {...field}
                        onChange={(e) => field.onChange(e.target.valueAsNumber)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Payment Status</FormLabel>
                    <Select
                      value={field.value}
                      onValueChange={field.onChange}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Pending">Pending</SelectItem>
                        <SelectItem value="Paid">Paid</SelectItem>
                        <SelectItem value="Overdue">Overdue</SelectItem>
                        <SelectItem value="Cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem className="md:col-span-2 lg:col-span-3">
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Add any additional notes here"
                        className="resize-none" 
                        rows={2}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="md:col-span-2 lg:col-span-3 flex justify-end space-x-3">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={handleCancel}
                  disabled={isPending}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={isPending}
                >
                  {isPending ? 'Processing...' : editingId ? 'Update Sales Entry' : 'Add Sales Entry'}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
      
      <DataTable
        title="Sales Log"
        data={salesLogs || []}
        columns={columns}
        isLoading={isLoading}
        totalCount={salesLogs?.length || 0}
        currentPage={currentPage}
        searchValue={searchValue}
        onPageChange={setCurrentPage}
        onSearch={setSearchValue}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onFilter={() => {}}
        onExport={() => {}}
      />
    </main>
  );
};

export default SalesLogPage;
