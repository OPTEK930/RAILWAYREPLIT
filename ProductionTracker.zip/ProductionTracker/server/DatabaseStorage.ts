import { eq } from "drizzle-orm";
import { db } from "./db";
import { 
  products, type Product, type InsertProduct,
  productionLogs, type ProductionLog, type InsertProductionLog,
  salesLogs, type SalesLog, type InsertSalesLog,
  purchases, type Purchase, type InsertPurchase,
  inventory, type Inventory, type InsertInventory,
  metrics, type Metric,
  activities, type Activity, type InsertActivity,
  users, type User, type InsertUser
} from "@shared/schema";
import { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  // Product methods
  async getAllProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }
  
  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product || undefined;
  }
  
  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db
      .insert(products)
      .values(product)
      .returning();
    return newProduct;
  }
  
  async updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const [updatedProduct] = await db
      .update(products)
      .set(product)
      .where(eq(products.id, id))
      .returning();
    return updatedProduct || undefined;
  }
  
  async deleteProduct(id: number): Promise<boolean> {
    const deleted = await db
      .delete(products)
      .where(eq(products.id, id))
      .returning({ id: products.id });
    return deleted.length > 0;
  }
  
  // Production Log methods
  async getAllProductionLogs(): Promise<ProductionLog[]> {
    return await db.select().from(productionLogs);
  }
  
  async getProductionLog(id: number): Promise<ProductionLog | undefined> {
    const [log] = await db.select().from(productionLogs).where(eq(productionLogs.id, id));
    return log || undefined;
  }
  
  async createProductionLog(log: InsertProductionLog): Promise<ProductionLog> {
    // Calculate total cost
    const totalCost = Number(log.quantity) * Number(log.unitCost);
    
    // Insert production log
    const [newLog] = await db
      .insert(productionLogs)
      .values({
        ...log,
        totalCost: totalCost as any,
        createdAt: new Date()
      })
      .returning();
    
    // Update inventory
    await this.updateInventory(log.productId, Number(log.quantity));
    
    // Create activity
    const product = await this.getProduct(log.productId);
    await this.createActivity({
      date: log.date as any,
      type: 'Production',
      description: `${product?.name} manufacturing`,
      quantity: `${log.quantity} ${product?.unit}`,
      value: `$${totalCost}`,
      status: log.status
    });
    
    // Update metrics
    await this.updateMetrics();
    
    return newLog;
  }
  
  async updateProductionLog(id: number, log: Partial<InsertProductionLog>): Promise<ProductionLog | undefined> {
    // Get existing log
    const existingLog = await this.getProductionLog(id);
    if (!existingLog) return undefined;
    
    // Calculate new quantities for inventory
    let quantityDiff = 0;
    if (log.quantity !== undefined) {
      quantityDiff = Number(log.quantity) - Number(existingLog.quantity);
    }
    
    // Calculate new total cost
    const unitCost = log.unitCost !== undefined ? Number(log.unitCost) : Number(existingLog.unitCost);
    const quantity = log.quantity !== undefined ? Number(log.quantity) : Number(existingLog.quantity);
    const totalCost = unitCost * quantity;
    
    // Update production log
    const [updatedLog] = await db
      .update(productionLogs)
      .set({
        ...log,
        totalCost: totalCost as any
      })
      .where(eq(productionLogs.id, id))
      .returning();
    
    // Update inventory if quantity changed
    if (quantityDiff !== 0) {
      await this.updateInventory(existingLog.productId, quantityDiff);
      await this.updateMetrics();
    }
    
    return updatedLog || undefined;
  }
  
  async deleteProductionLog(id: number): Promise<boolean> {
    // Get the log to be deleted
    const log = await this.getProductionLog(id);
    if (!log) return false;
    
    // Update inventory (subtract the deleted production quantity)
    await this.updateInventory(log.productId, -Number(log.quantity));
    await this.updateMetrics();
    
    // Delete the log
    const deleted = await db
      .delete(productionLogs)
      .where(eq(productionLogs.id, id))
      .returning({ id: productionLogs.id });
    
    return deleted.length > 0;
  }
  
  // Sales Log methods
  async getAllSalesLogs(): Promise<SalesLog[]> {
    return await db.select().from(salesLogs);
  }
  
  async getSalesLog(id: number): Promise<SalesLog | undefined> {
    const [log] = await db.select().from(salesLogs).where(eq(salesLogs.id, id));
    return log || undefined;
  }
  
  async createSalesLog(log: InsertSalesLog): Promise<SalesLog> {
    // Calculate total amount
    const totalAmount = Number(log.quantity) * Number(log.unitPrice);
    
    // Insert sales log
    const [newLog] = await db
      .insert(salesLogs)
      .values({
        ...log,
        totalAmount: totalAmount as any,
        createdAt: new Date()
      })
      .returning();
    
    // Update inventory (decrease by sold quantity)
    await this.updateInventory(log.productId, -Number(log.quantity));
    
    // Create activity
    const product = await this.getProduct(log.productId);
    await this.createActivity({
      date: log.date as any,
      type: 'Sale',
      description: `Invoice #${log.invoiceNumber} - ${log.customerName}`,
      quantity: `${log.quantity} ${product?.unit}`,
      value: `$${totalAmount}`,
      status: log.status
    });
    
    // Update metrics
    await this.updateMetrics();
    
    return newLog;
  }
  
  async updateSalesLog(id: number, log: Partial<InsertSalesLog>): Promise<SalesLog | undefined> {
    // Get existing log
    const existingLog = await this.getSalesLog(id);
    if (!existingLog) return undefined;
    
    // Calculate new quantities for inventory
    let quantityDiff = 0;
    if (log.quantity !== undefined) {
      quantityDiff = Number(existingLog.quantity) - Number(log.quantity);
    }
    
    // Calculate new total amount
    const unitPrice = log.unitPrice !== undefined ? Number(log.unitPrice) : Number(existingLog.unitPrice);
    const quantity = log.quantity !== undefined ? Number(log.quantity) : Number(existingLog.quantity);
    const totalAmount = unitPrice * quantity;
    
    // Update sales log
    const [updatedLog] = await db
      .update(salesLogs)
      .set({
        ...log,
        totalAmount: totalAmount as any
      })
      .where(eq(salesLogs.id, id))
      .returning();
    
    // Update inventory if quantity changed
    if (quantityDiff !== 0) {
      await this.updateInventory(existingLog.productId, quantityDiff);
      await this.updateMetrics();
    }
    
    return updatedLog || undefined;
  }
  
  async deleteSalesLog(id: number): Promise<boolean> {
    // Get the log to be deleted
    const log = await this.getSalesLog(id);
    if (!log) return false;
    
    // Update inventory (add back the deleted sales quantity)
    await this.updateInventory(log.productId, Number(log.quantity));
    await this.updateMetrics();
    
    // Delete the log
    const deleted = await db
      .delete(salesLogs)
      .where(eq(salesLogs.id, id))
      .returning({ id: salesLogs.id });
    
    return deleted.length > 0;
  }
  
  // Purchase methods
  async getAllPurchases(): Promise<Purchase[]> {
    return await db.select().from(purchases);
  }
  
  async getPurchase(id: number): Promise<Purchase | undefined> {
    const [purchase] = await db.select().from(purchases).where(eq(purchases.id, id));
    return purchase || undefined;
  }
  
  async createPurchase(purchase: InsertPurchase): Promise<Purchase> {
    // Calculate total cost
    const totalCost = Number(purchase.quantity) * Number(purchase.unitCost);
    
    // Insert purchase
    const [newPurchase] = await db
      .insert(purchases)
      .values({
        ...purchase,
        totalCost: totalCost as any,
        createdAt: new Date()
      })
      .returning();
    
    // Update inventory if status is Received
    if (purchase.status === 'Received') {
      await this.updateInventory(purchase.productId, Number(purchase.quantity));
    }
    
    // Create activity
    const product = await this.getProduct(purchase.productId);
    await this.createActivity({
      date: purchase.date as any,
      type: 'Purchase',
      description: `Order #${purchase.orderNumber} - ${purchase.supplierName}`,
      quantity: `${purchase.quantity} ${product?.unit}`,
      value: `$${totalCost}`,
      status: purchase.status
    });
    
    // Update metrics
    await this.updateMetrics();
    
    return newPurchase;
  }
  
  async updatePurchase(id: number, purchase: Partial<InsertPurchase>): Promise<Purchase | undefined> {
    // Get existing purchase
    const existingPurchase = await this.getPurchase(id);
    if (!existingPurchase) return undefined;
    
    // Calculate new total cost
    const unitCost = purchase.unitCost !== undefined ? Number(purchase.unitCost) : Number(existingPurchase.unitCost);
    const quantity = purchase.quantity !== undefined ? Number(purchase.quantity) : Number(existingPurchase.quantity);
    const totalCost = unitCost * quantity;
    
    // Update purchase
    const [updatedPurchase] = await db
      .update(purchases)
      .set({
        ...purchase,
        totalCost: totalCost as any
      })
      .where(eq(purchases.id, id))
      .returning();
    
    // Handle inventory updates if status changed to or from 'Received'
    if (purchase.status !== undefined) {
      if (purchase.status === 'Received' && existingPurchase.status !== 'Received') {
        // Status changed to Received - add to inventory
        await this.updateInventory(existingPurchase.productId, Number(existingPurchase.quantity));
        await this.updateMetrics();
      } else if (purchase.status !== 'Received' && existingPurchase.status === 'Received') {
        // Status changed from Received - remove from inventory
        await this.updateInventory(existingPurchase.productId, -Number(existingPurchase.quantity));
        await this.updateMetrics();
      }
    }
    
    return updatedPurchase || undefined;
  }
  
  async deletePurchase(id: number): Promise<boolean> {
    // Get the purchase to be deleted
    const purchase = await this.getPurchase(id);
    if (!purchase) return false;
    
    // Update inventory if the purchase was received
    if (purchase.status === 'Received') {
      await this.updateInventory(purchase.productId, -Number(purchase.quantity));
      await this.updateMetrics();
    }
    
    // Delete the purchase
    const deleted = await db
      .delete(purchases)
      .where(eq(purchases.id, id))
      .returning({ id: purchases.id });
    
    return deleted.length > 0;
  }
  
  // Inventory methods
  async getAllInventory(): Promise<Inventory[]> {
    return await db.select().from(inventory);
  }
  
  async getInventoryByProduct(productId: number): Promise<Inventory | undefined> {
    const [inventoryItem] = await db
      .select()
      .from(inventory)
      .where(eq(inventory.productId, productId));
    
    return inventoryItem || undefined;
  }
  
  async updateInventory(productId: number, quantityChange: number): Promise<Inventory> {
    const existingInventory = await this.getInventoryByProduct(productId);
    
    if (existingInventory) {
      // Update existing inventory item
      const newQuantity = existingInventory.quantity + quantityChange;
      
      const [updatedInventory] = await db
        .update(inventory)
        .set({
          quantity: newQuantity,
          lastUpdated: new Date()
        })
        .where(eq(inventory.id, existingInventory.id))
        .returning();
      
      return updatedInventory;
    } else {
      // Create new inventory entry
      const [newInventory] = await db
        .insert(inventory)
        .values({
          productId,
          quantity: quantityChange,
          lastUpdated: new Date()
        })
        .returning();
      
      return newInventory;
    }
  }
  
  // Metrics methods
  async getLatestMetrics(): Promise<Metric | undefined> {
    const metrics = await db.select().from(this.getMetricsTable());
    if (metrics.length === 0) return undefined;
    
    // Find the most recent metrics
    return metrics.reduce((latest, current) => {
      if (!latest) return current;
      return new Date(latest.lastUpdated) > new Date(current.lastUpdated) ? latest : current;
    }, null as Metric | null);
  }
  
  async updateMetrics(): Promise<Metric> {
    // Calculate metrics
    const productionLogs = await this.getAllProductionLogs();
    const salesLogs = await this.getAllSalesLogs();
    const purchaseLogs = await this.getAllPurchases();
    const inventoryItems = await this.getAllInventory();
    
    const totalProduction = productionLogs.reduce((sum, log) => sum + Number(log.quantity), 0);
    const totalSales = salesLogs.reduce((sum, log) => sum + Number(log.totalAmount), 0);
    const purchaseCosts = purchaseLogs.reduce((sum, purchase) => sum + Number(purchase.totalCost), 0);
    const currentInventory = inventoryItems.reduce((sum, item) => sum + item.quantity, 0);
    
    // Get existing metrics or create new ones
    const existingMetrics = await this.getLatestMetrics();
    const today = new Date();
    
    if (existingMetrics) {
      // Update existing metrics
      const [updatedMetrics] = await db
        .update(metrics)
        .set({
          date: today,
          totalProduction,
          totalSales: totalSales as any,
          purchaseCosts: purchaseCosts as any,
          currentInventory,
          lastUpdated: today
        })
        .where(eq(metrics.id, existingMetrics.id))
        .returning();
      
      return updatedMetrics;
    } else {
      // Create new metrics
      const [newMetrics] = await db
        .insert(metrics)
        .values({
          date: today,
          totalProduction,
          totalSales: totalSales as any,
          purchaseCosts: purchaseCosts as any,
          currentInventory,
          lastUpdated: today
        })
        .returning();
      
      return newMetrics;
    }
  }
  
  // Activity methods
  async getRecentActivities(limit: number): Promise<Activity[]> {
    return await db
      .select()
      .from(activities)
      .orderBy(() => ({ direction: 'desc', column: activities.createdAt }))
      .limit(limit);
  }
  
  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [newActivity] = await db
      .insert(activities)
      .values({
        ...activity,
        createdAt: new Date()
      })
      .returning();
    
    return newActivity;
  }
  
  // Low stock alert methods
  async getLowStockItems(): Promise<(Product & { currentStock: number })[]> {
    const products = await this.getAllProducts();
    const inventory = await this.getAllInventory();
    
    const result: (Product & { currentStock: number })[] = [];
    
    for (const product of products) {
      const inventoryItem = inventory.find(item => item.productId === product.id);
      const currentStock = inventoryItem ? inventoryItem.quantity : 0;
      
      if (currentStock < product.minStockLevel) {
        result.push({
          ...product,
          currentStock
        });
      }
    }
    
    return result;
  }
  
  // Helper method to handle metrics table reference
  private getMetricsTable() {
    return metrics;
  }
}