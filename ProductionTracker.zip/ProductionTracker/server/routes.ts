import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertProductSchema, 
  insertProductionLogSchema,
  insertSalesLogSchema,
  insertPurchaseSchema,
  insertInventorySchema,
  insertActivitySchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Products routes
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });
  
  app.get("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const product = await storage.getProduct(id);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });
  
  app.post("/api/products", async (req, res) => {
    try {
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      res.status(201).json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid product data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create product" });
    }
  });
  
  app.put("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertProductSchema.partial().parse(req.body);
      const product = await storage.updateProduct(id, validatedData);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid product data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update product" });
    }
  });
  
  app.delete("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteProduct(id);
      
      if (!success) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete product" });
    }
  });
  
  // Production Log routes
  app.get("/api/production-logs", async (req, res) => {
    try {
      const logs = await storage.getAllProductionLogs();
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch production logs" });
    }
  });
  
  app.get("/api/production-logs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const log = await storage.getProductionLog(id);
      
      if (!log) {
        return res.status(404).json({ message: "Production log not found" });
      }
      
      res.json(log);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch production log" });
    }
  });
  
  app.post("/api/production-logs", async (req, res) => {
    try {
      const validatedData = insertProductionLogSchema.parse(req.body);
      const log = await storage.createProductionLog(validatedData);
      res.status(201).json(log);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid production log data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create production log" });
    }
  });
  
  app.put("/api/production-logs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertProductionLogSchema.partial().parse(req.body);
      const log = await storage.updateProductionLog(id, validatedData);
      
      if (!log) {
        return res.status(404).json({ message: "Production log not found" });
      }
      
      res.json(log);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid production log data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update production log" });
    }
  });
  
  app.delete("/api/production-logs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteProductionLog(id);
      
      if (!success) {
        return res.status(404).json({ message: "Production log not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete production log" });
    }
  });
  
  // Sales Log routes
  app.get("/api/sales-logs", async (req, res) => {
    try {
      const logs = await storage.getAllSalesLogs();
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sales logs" });
    }
  });
  
  app.get("/api/sales-logs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const log = await storage.getSalesLog(id);
      
      if (!log) {
        return res.status(404).json({ message: "Sales log not found" });
      }
      
      res.json(log);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sales log" });
    }
  });
  
  app.post("/api/sales-logs", async (req, res) => {
    try {
      const validatedData = insertSalesLogSchema.parse(req.body);
      const log = await storage.createSalesLog(validatedData);
      res.status(201).json(log);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid sales log data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create sales log" });
    }
  });
  
  app.put("/api/sales-logs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertSalesLogSchema.partial().parse(req.body);
      const log = await storage.updateSalesLog(id, validatedData);
      
      if (!log) {
        return res.status(404).json({ message: "Sales log not found" });
      }
      
      res.json(log);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid sales log data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update sales log" });
    }
  });
  
  app.delete("/api/sales-logs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteSalesLog(id);
      
      if (!success) {
        return res.status(404).json({ message: "Sales log not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete sales log" });
    }
  });
  
  // Purchases routes
  app.get("/api/purchases", async (req, res) => {
    try {
      const purchases = await storage.getAllPurchases();
      res.json(purchases);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch purchases" });
    }
  });
  
  app.get("/api/purchases/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const purchase = await storage.getPurchase(id);
      
      if (!purchase) {
        return res.status(404).json({ message: "Purchase not found" });
      }
      
      res.json(purchase);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch purchase" });
    }
  });
  
  app.post("/api/purchases", async (req, res) => {
    try {
      const validatedData = insertPurchaseSchema.parse(req.body);
      const purchase = await storage.createPurchase(validatedData);
      res.status(201).json(purchase);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid purchase data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create purchase" });
    }
  });
  
  app.put("/api/purchases/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertPurchaseSchema.partial().parse(req.body);
      const purchase = await storage.updatePurchase(id, validatedData);
      
      if (!purchase) {
        return res.status(404).json({ message: "Purchase not found" });
      }
      
      res.json(purchase);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid purchase data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update purchase" });
    }
  });
  
  app.delete("/api/purchases/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deletePurchase(id);
      
      if (!success) {
        return res.status(404).json({ message: "Purchase not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete purchase" });
    }
  });
  
  // Inventory routes
  app.get("/api/inventory", async (req, res) => {
    try {
      const inventory = await storage.getAllInventory();
      res.json(inventory);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch inventory" });
    }
  });
  
  app.get("/api/inventory/:productId", async (req, res) => {
    try {
      const productId = parseInt(req.params.productId);
      const inventory = await storage.getInventoryByProduct(productId);
      
      if (!inventory) {
        return res.status(404).json({ message: "Inventory not found for this product" });
      }
      
      res.json(inventory);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch inventory" });
    }
  });
  
  // Dashboard routes
  app.get("/api/metrics", async (req, res) => {
    try {
      const metrics = await storage.getLatestMetrics();
      
      if (!metrics) {
        return res.status(404).json({ message: "No metrics available" });
      }
      
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch metrics" });
    }
  });
  
  app.get("/api/activities", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const activities = await storage.getRecentActivities(limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });
  
  app.get("/api/low-stock", async (req, res) => {
    try {
      const lowStockItems = await storage.getLowStockItems();
      res.json(lowStockItems);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch low stock items" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
