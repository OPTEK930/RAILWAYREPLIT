import { 
  products, type Product, type InsertProduct,
  productionLogs, type ProductionLog, type InsertProductionLog,
  salesLogs, type SalesLog, type InsertSalesLog,
  purchases, type Purchase, type InsertPurchase,
  inventory, type Inventory, type InsertInventory,
  metrics, type Metric,
  activities, type Activity, type InsertActivity
} from "@shared/schema";
import { User, InsertUser, users } from "@shared/schema";

export interface IStorage {
  // User methods from original template
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Product methods
  getAllProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  
  // Production Log methods
  getAllProductionLogs(): Promise<ProductionLog[]>;
  getProductionLog(id: number): Promise<ProductionLog | undefined>;
  createProductionLog(log: InsertProductionLog): Promise<ProductionLog>;
  updateProductionLog(id: number, log: Partial<InsertProductionLog>): Promise<ProductionLog | undefined>;
  deleteProductionLog(id: number): Promise<boolean>;
  
  // Sales Log methods
  getAllSalesLogs(): Promise<SalesLog[]>;
  getSalesLog(id: number): Promise<SalesLog | undefined>;
  createSalesLog(log: InsertSalesLog): Promise<SalesLog>;
  updateSalesLog(id: number, log: Partial<InsertSalesLog>): Promise<SalesLog | undefined>;
  deleteSalesLog(id: number): Promise<boolean>;
  
  // Purchase methods
  getAllPurchases(): Promise<Purchase[]>;
  getPurchase(id: number): Promise<Purchase | undefined>;
  createPurchase(purchase: InsertPurchase): Promise<Purchase>;
  updatePurchase(id: number, purchase: Partial<InsertPurchase>): Promise<Purchase | undefined>;
  deletePurchase(id: number): Promise<boolean>;
  
  // Inventory methods
  getAllInventory(): Promise<Inventory[]>;
  getInventoryByProduct(productId: number): Promise<Inventory | undefined>;
  updateInventory(productId: number, quantity: number): Promise<Inventory>;
  
  // Metrics methods
  getLatestMetrics(): Promise<Metric | undefined>;
  updateMetrics(): Promise<Metric>;
  
  // Activity methods
  getRecentActivities(limit: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  
  // Low stock alert methods
  getLowStockItems(): Promise<(Product & { currentStock: number })[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private productsData: Map<number, Product>;
  private productionLogsData: Map<number, ProductionLog>;
  private salesLogsData: Map<number, SalesLog>;
  private purchasesData: Map<number, Purchase>;
  private inventoryData: Map<number, Inventory>;
  private metricsData: Map<number, Metric>;
  private activitiesData: Map<number, Activity>;
  
  private userId: number;
  private productId: number;
  private productionLogId: number;
  private salesLogId: number;
  private purchaseId: number;
  private inventoryId: number;
  private metricId: number;
  private activityId: number;

  constructor() {
    this.users = new Map();
    this.productsData = new Map();
    this.productionLogsData = new Map();
    this.salesLogsData = new Map();
    this.purchasesData = new Map();
    this.inventoryData = new Map();
    this.metricsData = new Map();
    this.activitiesData = new Map();
    
    this.userId = 1;
    this.productId = 1;
    this.productionLogId = 1;
    this.salesLogId = 1;
    this.purchaseId = 1;
    this.inventoryId = 1;
    this.metricId = 1;
    this.activityId = 1;
    
    // Initialize with some sample data
    this.initializeSampleData();
  }
  
  private initializeSampleData() {
    // Add some products
    const product1: InsertProduct = {
      name: "Product A",
      description: "First product",
      unit: "units",
      minStockLevel: 20
    };
    const product2: InsertProduct = {
      name: "Raw Material B",
      description: "Raw material for production",
      unit: "kg",
      minStockLevel: 50
    };
    
    this.createProduct(product1);
    this.createProduct(product2);
    
    // Initialize inventory for these products
    this.updateInventory(1, 100);
    this.updateInventory(2, 200);
    
    // Create initial metrics
    const today = new Date();
    const initialMetrics: Partial<Metric> = {
      date: today,
      totalProduction: 1245,
      totalSales: 87362,
      purchaseCosts: 35841,
      currentInventory: 3782,
      lastUpdated: today
    };
    
    this.metricsData.set(this.metricId++, {
      id: 1,
      ...initialMetrics,
    } as Metric);
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Product methods
  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.productsData.values());
  }
  
  async getProduct(id: number): Promise<Product | undefined> {
    return this.productsData.get(id);
  }
  
  async createProduct(product: InsertProduct): Promise<Product> {
    const id = this.productId++;
    const newProduct = { ...product, id };
    this.productsData.set(id, newProduct);
    return newProduct;
  }
  
  async updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const existingProduct = this.productsData.get(id);
    if (!existingProduct) return undefined;
    
    const updatedProduct = { ...existingProduct, ...product };
    this.productsData.set(id, updatedProduct);
    return updatedProduct;
  }
  
  async deleteProduct(id: number): Promise<boolean> {
    return this.productsData.delete(id);
  }
  
  // Production Log methods
  async getAllProductionLogs(): Promise<ProductionLog[]> {
    return Array.from(this.productionLogsData.values());
  }
  
  async getProductionLog(id: number): Promise<ProductionLog | undefined> {
    return this.productionLogsData.get(id);
  }
  
  async createProductionLog(log: InsertProductionLog): Promise<ProductionLog> {
    const id = this.productionLogId++;
    const totalCost = Number(log.quantity) * Number(log.unitCost);
    const newLog: ProductionLog = { 
      ...log, 
      id, 
      totalCost: totalCost as any, 
      createdAt: new Date()
    };
    
    this.productionLogsData.set(id, newLog);
    
    // Update inventory
    await this.updateInventory(log.productId, Number(log.quantity));
    
    // Create activity
    const product = await this.getProduct(log.productId);
    await this.createActivity({
      date: log.date as any,
      type: 'Production',
      description: `${product?.name} manufacturing`,
      quantity: `${log.quantity} ${product?.unit}`,
      value: `$${totalCost}`,
      status: log.status
    });
    
    // Update metrics
    await this.updateMetrics();
    
    return newLog;
  }
  
  async updateProductionLog(id: number, log: Partial<InsertProductionLog>): Promise<ProductionLog | undefined> {
    const existingLog = this.productionLogsData.get(id);
    if (!existingLog) return undefined;
    
    // Calculate new quantities for inventory
    let quantityDiff = 0;
    if (log.quantity !== undefined) {
      quantityDiff = Number(log.quantity) - Number(existingLog.quantity);
    }
    
    // Calculate new total cost
    const unitCost = log.unitCost !== undefined ? Number(log.unitCost) : Number(existingLog.unitCost);
    const quantity = log.quantity !== undefined ? Number(log.quantity) : Number(existingLog.quantity);
    const totalCost = unitCost * quantity;
    
    const updatedLog = { 
      ...existingLog, 
      ...log, 
      totalCost: totalCost as any 
    };
    
    this.productionLogsData.set(id, updatedLog);
    
    // Update inventory if quantity changed
    if (quantityDiff !== 0) {
      await this.updateInventory(existingLog.productId, quantityDiff);
      await this.updateMetrics();
    }
    
    return updatedLog;
  }
  
  async deleteProductionLog(id: number): Promise<boolean> {
    const log = this.productionLogsData.get(id);
    if (!log) return false;
    
    // Update inventory (subtract the deleted production quantity)
    await this.updateInventory(log.productId, -Number(log.quantity));
    await this.updateMetrics();
    
    return this.productionLogsData.delete(id);
  }
  
  // Sales Log methods
  async getAllSalesLogs(): Promise<SalesLog[]> {
    return Array.from(this.salesLogsData.values());
  }
  
  async getSalesLog(id: number): Promise<SalesLog | undefined> {
    return this.salesLogsData.get(id);
  }
  
  async createSalesLog(log: InsertSalesLog): Promise<SalesLog> {
    const id = this.salesLogId++;
    const totalAmount = Number(log.quantity) * Number(log.unitPrice);
    const newLog: SalesLog = { 
      ...log, 
      id, 
      totalAmount: totalAmount as any, 
      createdAt: new Date()
    };
    
    this.salesLogsData.set(id, newLog);
    
    // Update inventory (decrease by sold quantity)
    await this.updateInventory(log.productId, -Number(log.quantity));
    
    // Create activity
    const product = await this.getProduct(log.productId);
    await this.createActivity({
      date: log.date as any,
      type: 'Sale',
      description: `Invoice #${log.invoiceNumber} - ${log.customerName}`,
      quantity: `${log.quantity} ${product?.unit}`,
      value: `$${totalAmount}`,
      status: log.status
    });
    
    // Update metrics
    await this.updateMetrics();
    
    return newLog;
  }
  
  async updateSalesLog(id: number, log: Partial<InsertSalesLog>): Promise<SalesLog | undefined> {
    const existingLog = this.salesLogsData.get(id);
    if (!existingLog) return undefined;
    
    // Calculate new quantities for inventory
    let quantityDiff = 0;
    if (log.quantity !== undefined) {
      quantityDiff = Number(existingLog.quantity) - Number(log.quantity);
    }
    
    // Calculate new total amount
    const unitPrice = log.unitPrice !== undefined ? Number(log.unitPrice) : Number(existingLog.unitPrice);
    const quantity = log.quantity !== undefined ? Number(log.quantity) : Number(existingLog.quantity);
    const totalAmount = unitPrice * quantity;
    
    const updatedLog = { 
      ...existingLog, 
      ...log, 
      totalAmount: totalAmount as any 
    };
    
    this.salesLogsData.set(id, updatedLog);
    
    // Update inventory if quantity changed
    if (quantityDiff !== 0) {
      await this.updateInventory(existingLog.productId, quantityDiff);
      await this.updateMetrics();
    }
    
    return updatedLog;
  }
  
  async deleteSalesLog(id: number): Promise<boolean> {
    const log = this.salesLogsData.get(id);
    if (!log) return false;
    
    // Update inventory (add back the deleted sales quantity)
    await this.updateInventory(log.productId, Number(log.quantity));
    await this.updateMetrics();
    
    return this.salesLogsData.delete(id);
  }
  
  // Purchase methods
  async getAllPurchases(): Promise<Purchase[]> {
    return Array.from(this.purchasesData.values());
  }
  
  async getPurchase(id: number): Promise<Purchase | undefined> {
    return this.purchasesData.get(id);
  }
  
  async createPurchase(purchase: InsertPurchase): Promise<Purchase> {
    const id = this.purchaseId++;
    const totalCost = Number(purchase.quantity) * Number(purchase.unitCost);
    const newPurchase: Purchase = { 
      ...purchase, 
      id, 
      totalCost: totalCost as any, 
      createdAt: new Date()
    };
    
    this.purchasesData.set(id, newPurchase);
    
    // Update inventory if status is Received
    if (purchase.status === 'Received') {
      await this.updateInventory(purchase.productId, Number(purchase.quantity));
    }
    
    // Create activity
    const product = await this.getProduct(purchase.productId);
    await this.createActivity({
      date: purchase.date as any,
      type: 'Purchase',
      description: `Order #${purchase.orderNumber} - ${purchase.supplierName}`,
      quantity: `${purchase.quantity} ${product?.unit}`,
      value: `$${totalCost}`,
      status: purchase.status
    });
    
    // Update metrics
    await this.updateMetrics();
    
    return newPurchase;
  }
  
  async updatePurchase(id: number, purchase: Partial<InsertPurchase>): Promise<Purchase | undefined> {
    const existingPurchase = this.purchasesData.get(id);
    if (!existingPurchase) return undefined;
    
    // Calculate new total cost
    const unitCost = purchase.unitCost !== undefined ? Number(purchase.unitCost) : Number(existingPurchase.unitCost);
    const quantity = purchase.quantity !== undefined ? Number(purchase.quantity) : Number(existingPurchase.quantity);
    const totalCost = unitCost * quantity;
    
    const updatedPurchase = { 
      ...existingPurchase, 
      ...purchase, 
      totalCost: totalCost as any 
    };
    
    this.purchasesData.set(id, updatedPurchase);
    
    // Handle inventory updates if status changed to or from 'Received'
    if (purchase.status !== undefined) {
      if (purchase.status === 'Received' && existingPurchase.status !== 'Received') {
        // Status changed to Received - add to inventory
        await this.updateInventory(existingPurchase.productId, Number(existingPurchase.quantity));
        await this.updateMetrics();
      } else if (purchase.status !== 'Received' && existingPurchase.status === 'Received') {
        // Status changed from Received - remove from inventory
        await this.updateInventory(existingPurchase.productId, -Number(existingPurchase.quantity));
        await this.updateMetrics();
      }
    }
    
    return updatedPurchase;
  }
  
  async deletePurchase(id: number): Promise<boolean> {
    const purchase = this.purchasesData.get(id);
    if (!purchase) return false;
    
    // Update inventory if the purchase was received
    if (purchase.status === 'Received') {
      await this.updateInventory(purchase.productId, -Number(purchase.quantity));
      await this.updateMetrics();
    }
    
    return this.purchasesData.delete(id);
  }
  
  // Inventory methods
  async getAllInventory(): Promise<Inventory[]> {
    return Array.from(this.inventoryData.values());
  }
  
  async getInventoryByProduct(productId: number): Promise<Inventory | undefined> {
    return Array.from(this.inventoryData.values()).find(
      (inv) => inv.productId === productId,
    );
  }
  
  async updateInventory(productId: number, quantityChange: number): Promise<Inventory> {
    const existingInventory = await this.getInventoryByProduct(productId);
    
    if (existingInventory) {
      const newQuantity = existingInventory.quantity + quantityChange;
      const updatedInventory = { 
        ...existingInventory, 
        quantity: newQuantity,
        lastUpdated: new Date()
      };
      
      this.inventoryData.set(existingInventory.id, updatedInventory);
      return updatedInventory;
    } else {
      // Create new inventory entry
      const id = this.inventoryId++;
      const newInventory: Inventory = {
        id,
        productId,
        quantity: quantityChange,
        lastUpdated: new Date()
      };
      
      this.inventoryData.set(id, newInventory);
      return newInventory;
    }
  }
  
  // Metrics methods
  async getLatestMetrics(): Promise<Metric | undefined> {
    const metrics = Array.from(this.metricsData.values());
    if (metrics.length === 0) return undefined;
    
    // Find the most recent metrics
    return metrics.reduce((latest, current) => {
      if (!latest) return current;
      if (new Date(current.lastUpdated) > new Date(latest.lastUpdated)) return current;
      return latest;
    }, undefined as Metric | undefined);
  }
  
  async updateMetrics(): Promise<Metric> {
    // Calculate new metrics
    const today = new Date();
    const productionLogs = await this.getAllProductionLogs();
    const salesLogs = await this.getAllSalesLogs();
    const purchases = await this.getAllPurchases();
    const inventoryItems = await this.getAllInventory();
    
    const totalProduction = productionLogs.reduce((sum, log) => sum + Number(log.quantity), 0);
    const totalSales = salesLogs.reduce((sum, log) => sum + Number(log.totalAmount), 0);
    const purchaseCosts = purchases.reduce((sum, purchase) => sum + Number(purchase.totalCost), 0);
    const currentInventory = inventoryItems.reduce((sum, item) => sum + item.quantity, 0);
    
    const id = this.metricId++;
    const newMetrics: Metric = {
      id,
      date: today as any,
      totalProduction,
      totalSales: totalSales as any,
      purchaseCosts: purchaseCosts as any,
      currentInventory,
      lastUpdated: today
    };
    
    this.metricsData.set(id, newMetrics);
    return newMetrics;
  }
  
  // Activity methods
  async getRecentActivities(limit: number): Promise<Activity[]> {
    const activities = Array.from(this.activitiesData.values());
    return activities
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }
  
  async createActivity(activity: InsertActivity): Promise<Activity> {
    const id = this.activityId++;
    const newActivity: Activity = {
      ...activity,
      id,
      createdAt: new Date()
    };
    
    this.activitiesData.set(id, newActivity);
    return newActivity;
  }
  
  // Low stock alert methods
  async getLowStockItems(): Promise<(Product & { currentStock: number })[]> {
    const products = await this.getAllProducts();
    const inventory = await this.getAllInventory();
    
    const lowStockItems = [];
    
    for (const product of products) {
      const inventoryItem = inventory.find(item => item.productId === product.id);
      const currentStock = inventoryItem ? inventoryItem.quantity : 0;
      
      if (currentStock < product.minStockLevel) {
        lowStockItems.push({
          ...product,
          currentStock
        });
      }
    }
    
    return lowStockItems;
  }
}

// Import the database storage implementation
import { DatabaseStorage } from "./DatabaseStorage";

// Use the database storage implementation
export const storage = new DatabaseStorage();
