import { pgTable, text, serial, integer, boolean, timestamp, numeric, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

// Product schema
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  unit: text("unit").notNull(),
  minStockLevel: integer("min_stock_level").notNull().default(10),
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
});

// Production log schema
export const productionLogs = pgTable("production_logs", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  productId: integer("product_id").notNull(),
  batchNumber: text("batch_number").notNull(),
  quantity: integer("quantity").notNull(),
  unitCost: numeric("unit_cost").notNull(),
  totalCost: numeric("total_cost").notNull(),
  status: text("status").notNull().default("In Progress"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertProductionLogSchema = createInsertSchema(productionLogs).omit({
  id: true,
  totalCost: true,
  createdAt: true,
});

// Sales log schema
export const salesLogs = pgTable("sales_logs", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  invoiceNumber: text("invoice_number").notNull(),
  customerName: text("customer_name").notNull(),
  productId: integer("product_id").notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: numeric("unit_price").notNull(),
  totalAmount: numeric("total_amount").notNull(),
  status: text("status").notNull().default("Pending"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertSalesLogSchema = createInsertSchema(salesLogs).omit({
  id: true,
  totalAmount: true,
  createdAt: true,
});

// Purchases schema
export const purchases = pgTable("purchases", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  orderNumber: text("order_number").notNull(),
  supplierName: text("supplier_name").notNull(),
  productId: integer("product_id").notNull(),
  quantity: integer("quantity").notNull(),
  unitCost: numeric("unit_cost").notNull(),
  totalCost: numeric("total_cost").notNull(),
  status: text("status").notNull().default("Ordered"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertPurchaseSchema = createInsertSchema(purchases).omit({
  id: true,
  totalCost: true,
  createdAt: true,
});

// Inventory schema
export const inventory = pgTable("inventory", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  quantity: integer("quantity").notNull().default(0),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const insertInventorySchema = createInsertSchema(inventory).omit({
  id: true,
  lastUpdated: true,
});

// Dashboard metrics schema
export const metrics = pgTable("metrics", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  totalProduction: integer("total_production").notNull().default(0),
  totalSales: numeric("total_sales").notNull().default(0),
  purchaseCosts: numeric("purchase_costs").notNull().default(0),
  currentInventory: integer("current_inventory").notNull().default(0),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

// Types for frontend and backend use
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type ProductionLog = typeof productionLogs.$inferSelect;
export type InsertProductionLog = z.infer<typeof insertProductionLogSchema>;

export type SalesLog = typeof salesLogs.$inferSelect;
export type InsertSalesLog = z.infer<typeof insertSalesLogSchema>;

export type Purchase = typeof purchases.$inferSelect;
export type InsertPurchase = z.infer<typeof insertPurchaseSchema>;

export type Inventory = typeof inventory.$inferSelect;
export type InsertInventory = z.infer<typeof insertInventorySchema>;

export type Metric = typeof metrics.$inferSelect;

// Define Activity schema for recent activities on dashboard
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  type: text("type").notNull(), // 'Production', 'Sale', 'Purchase', 'Inventory'
  description: text("description").notNull(),
  quantity: text("quantity"),
  value: text("value"),
  status: text("status").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Activity = typeof activities.$inferSelect;
export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
});
export type InsertActivity = z.infer<typeof insertActivitySchema>;
